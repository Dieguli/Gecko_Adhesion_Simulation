#include <stdlib.h>
#include "World.h"
#include "TetraMesh.h"
#include "Draw.h"
#include "PhysicsParams.h"
#include "Utils.h"

//---------------------------------------------------------------------------

#define INIT_ARRAY_SIZE 1000

//-----------------------------------------------------------
World::World(char *applicationPath)
//-----------------------------------------------------------
{
  _tetraMeshes = new TetraMesh*[INIT_ARRAY_SIZE];
  _numTetraMeshes = 0;
  _tetraMeshesSize = INIT_ARRAY_SIZE;
  _groundPlaneY = 0.0;

  setupTestWorld();
}


//-----------------------------------------------------------
World::~World()
//-----------------------------------------------------------
{
  int i,j;

  for (i = 0; i < _numTetraMeshes; i++) {
    _tetraMeshes[i]->deleteAllObjects();
    delete _tetraMeshes[i];
  }
  delete[] _tetraMeshes;
}


//-----------------------------------------------------------
void World::setupTestWorld()
//-----------------------------------------------------------
{
  Vector3d trans;
  trans.setZero();
  TetraMesh *mesh;

  trans.y += 0.2;
  mesh = new TetraMesh(this, 3,15,3,0.02, trans);
  add(mesh);
  mesh->fixTop(0.1);

  physicsParams.warpedStiffness = true;

  draw3d.drawVertices = true;
  draw3d.drawTetras = true;
}


//-----------------------------------------------------------
void World::add(TetraMesh *mesh)
//-----------------------------------------------------------
{
  if (_numTetraMeshes >= _tetraMeshesSize) {
    _tetraMeshesSize *= 2;
    TetraMesh **newList = new TetraMesh*[_tetraMeshesSize];
    for (int i = 0; i < _numTetraMeshes; i++)
      newList[i] = _tetraMeshes[i];
    delete[] _tetraMeshes;
    _tetraMeshes = newList;
  }
  _tetraMeshes[_numTetraMeshes] = mesh;
  _numTetraMeshes++;
}


//-----------------------------------------------------------
void World::animate()
//-----------------------------------------------------------
{
  for (int i = 0; i < _numTetraMeshes; i++) {
    _tetraMeshes[i]->animate(1);
  }
}


//-----------------------------------------------------------
void World::draw()
//-----------------------------------------------------------
{
  int i;

  draw3d.groundPlane(_groundPlaneY);

  for (int i = 0; i < _numTetraMeshes; i++) {
    _tetraMeshes[i]->draw();
  }
}


//-----------------------------------------------------------
void World::mouseDown(int x, int y)
//-----------------------------------------------------------
{
  float depth, minDepth;
  int mini = -1;

  for (int i = 0; i < _numTetraMeshes; i++) {
    if (_tetraMeshes[i]->findClosestVertex(x, y, depth) != NULL) {
      if (mini < 0 || depth < minDepth) {
        minDepth = depth;
        mini = i;
      }
    }
  }
  if (mini < 0) return;
  _tetraMeshes[mini]->mouseDown(x,y);
}

//-----------------------------------------------------------
void World::mouseMove(int x, int y)
//-----------------------------------------------------------
{
  for (int i = 0; i < _numTetraMeshes; i++) {
    _tetraMeshes[i]->mouseMove(x,y);
  }
}

//-----------------------------------------------------------
void World::mouseUp(int x, int y)
//-----------------------------------------------------------
{
  for (int i = 0; i < _numTetraMeshes; i++) {
    _tetraMeshes[i]->mouseUp(x,y);
  }
}

//-----------------------------------------------------------
void World::getBounds(Bounds3d &bounds)
//-----------------------------------------------------------
{
  if (_numTetraMeshes <= 0) {
    bounds.clear();
    return;
  }

  _tetraMeshes[0]->getBounds(bounds);

  for (int i = 1; i < _numTetraMeshes; i++) {
    Bounds3d boundsi;
    _tetraMeshes[i]->getBounds(boundsi);
    bounds.combine(bounds, boundsi);
  }
}


//-----------------------------------------------------------
int World::numTetras()
//-----------------------------------------------------------
{
  int num = 0;
  for (int i = 0; i < _numTetraMeshes; i++)
    num += _tetraMeshes[i]->numTetras();
  return num;
}


//-----------------------------------------------------------
int World::numVertices()
//-----------------------------------------------------------
{
  int num = 0;
  for (int i = 0; i < _numTetraMeshes; i++)
    num += _tetraMeshes[i]->numVertices();
  return num;
}



